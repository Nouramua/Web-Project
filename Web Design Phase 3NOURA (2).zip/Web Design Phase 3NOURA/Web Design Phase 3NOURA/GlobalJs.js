// ===== Themes =====
function toggleTheme() {
    const body = document.body;
    const button = document.querySelector('.theme-toggle-btn');
    
    const isDarkMode = body.classList.contains('theme-dark');
    
    if (isDarkMode) {
        body.classList.remove('theme-dark');
        localStorage.setItem('theme', 'light');
        if (button) button.textContent = '🌙 Dark Mode';
    } else {
        body.classList.add('theme-dark');
        localStorage.setItem('theme', 'dark');
        if (button) button.textContent = '☀️ Light Mode';
    }
}

function loadSavedTheme() {
    if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('theme-dark');
        const button = document.querySelector('.theme-toggle-btn');
        if (button) button.textContent = '☀️ Light Mode';
    }
}

// ===== Go Back Up Button =====
function initBackToTop() {
    const backToTopBtn = document.getElementById('backToTop');
    
    if (backToTopBtn) {
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                backToTopBtn.style.display = 'block';
            } else {
                backToTopBtn.style.display = 'none';
            }
        });

        backToTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}

// ===== Live Clock =====
function initLiveClock() {
    function updateClock() {
        const now = new Date();
        const options = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true 
        };
        
        const dateTimeString = now.toLocaleDateString('en-SA', options);
        const clockElement = document.getElementById('liveClock');
        if (clockElement) {
            clockElement.textContent = dateTimeString;
        }
    }

    setInterval(updateClock, 1000);
    updateClock();
}

document.addEventListener('DOMContentLoaded', function() {
    loadSavedTheme();
    initBackToTop();
    initLiveClock();
});

// =========== services page  ===================

document.addEventListener("DOMContentLoaded", function () {

    document.querySelectorAll(".card-grid").forEach(grid => {
        shuffleCards(grid);
    });

  
    document.querySelectorAll(".idsortOptions").forEach(select => {
        select.addEventListener("change", function () {
            const section = this.closest(".service-section");
            const grid = section.querySelector(".card-grid");
            sortCards(grid, this.value);
        });
    });

    function shuffleCards(grid) {
        let cards = Array.from(grid.children);
        cards.sort(() => Math.random() - 0.5);
        cards.forEach(card => grid.appendChild(card));
    }


    function sortCards(grid, type) {

        let cards = Array.from(grid.children);

        cards.sort((a, b) => {

            let nameA = a.querySelector("h4").innerText.trim();
            let nameB = b.querySelector("h4").innerText.trim();

            let priceA = parseFloat(a.querySelector(".price").innerText.replace(/[^0-9.]/g, ''));
            let priceB = parseFloat(b.querySelector(".price").innerText.replace(/[^0-9.]/g, ''));

            let hasOfferA = a.querySelector(".offer-tag") ? 1 : 0;
            let hasOfferB = b.querySelector(".offer-tag") ? 1 : 0;

            switch (type) {
                case "A-Z":
                    return nameA.localeCompare(nameB);

                case "Z-A":
                    return nameB.localeCompare(nameA);

                case "low-high":
                    return priceA - priceB;

                case "high-low":
                    return priceB - priceA;

                case "offers":
                    return hasOfferB - hasOfferA;

                default:
                    return 0;
            }
        });

        cards.forEach(card => grid.appendChild(card));
    }

});

// =========== services provider page ===================
document.addEventListener("DOMContentLoaded", function () {

    if (document.querySelector(".form-page-main")) {

        const form = document.querySelector("form");
        const photoInput = document.getElementById("photoUpload");

        form.addEventListener("submit", function (e) {
            e.preventDefault();

            let category = document.getElementById("service-category")?.value;
            let name = document.getElementById("service-name").value.trim();
            let price = document.getElementById("service-price").value.trim();
            let desc = document.getElementById("description").value.trim();
            let city = document.getElementById("service-city").value.trim();
            let photoFile = photoInput.files[0];

            if (!category) {
                alert("Please select a service category.");
                return;
            }

            if (!name || !price || !desc || !city) {
                alert("Please fill ALL fields.");
                form.reportValidity();
                return;
            }

            if (!photoFile) {
                alert("Please upload a service photo.");
                photoInput.reportValidity();
                return;
            }

            if (!isNaN(name.charAt(0))) {
                alert("Service name cannot start with a number.");
                return;
            }

            if (isNaN(price)) {
                alert("Price must be a NUMBER.");
                return;
            }

            if (!isNaN(city)) {
                alert("City name cannot contain numbers.");
                return;
            }

            let reader = new FileReader();
            reader.onload = function () {

                let newService = {
                    category: category,
                    name: name,
                    price: price,
                    desc: desc,
                    city: city,
                    photo: reader.result
                };

                let services = JSON.parse(localStorage.getItem("providerServices")) || [];

                services.push(newService);

                localStorage.setItem("providerServices", JSON.stringify(services));

                alert(`Service "${name}" added successfully!`);

                form.reset();
            };

            reader.readAsDataURL(photoFile);
        });
    }

    if (document.querySelector(".provider-dashboard-main")) {

        let services = JSON.parse(localStorage.getItem("providerServices")) || [];

        let expContainer   = document.getElementById("expContainer");
        let hotelContainer = document.getElementById("hotelContainer");
        let restContainer  = document.getElementById("restContainer");

        services.forEach(service => {

            let card = document.createElement("article");
            card.classList.add("card");

            card.innerHTML = `
                <div class="image-wrap">
                    <img class="card-img" src="${service.photo}" alt="Service Photo">
                </div>

                <div class="card-body">
                    <div class="title-row">
                        <h4>${service.name}</h4>
                        <span class="price">${service.price} SAR</span>
                    </div>
                    <p class="desc">${service.desc}</p>

                    <div class="city">
                        <img src="images/location.png" alt="Location Icon" class="location-icon"> ${service.city}
                    </div>
                </div>
            `;

            if (service.category === "experience") {
                expContainer.appendChild(card);
            }
            else if (service.category === "hotel") {
                hotelContainer.appendChild(card);
            }
            else if (service.category === "restaurant") {
                restContainer.appendChild(card);
            }
        });
    }

});
